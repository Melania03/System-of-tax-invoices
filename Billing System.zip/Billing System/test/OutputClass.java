import java.io.*;
import java.util.*;

public class OutputClass {
        Gestiune obj=Gestiune.getInstance();
    public void Scriere(File f, File f1, File f2) throws FileNotFoundException, IOException{
        int i, j,k, indice;
        double min;
        String m;
        ArrayList<Magazin> magazineOrdine=new ArrayList<>();
        obj.citireTaxe(f);
        obj.citireProduse(f1);
        obj.citireMagazine(f2);
        Set keys = obj.taxe.keySet();
        
        //sortez vectorul de magazine in ordinea crescatoare a totalului fara taxe
        for(i=0; i<obj.magazine.size(); i++){
            min=obj.magazine.get(0).getTotalFaraTaxe();
            indice=0;
            for(j=1; j<obj.magazine.size(); j++)
                if(obj.magazine.get(j).getTotalFaraTaxe()<min && !magazineOrdine.contains(obj.magazine.get(j))){
                    min=obj.magazine.get(j).getTotalFaraTaxe();
                    indice=j;
                }
            magazineOrdine.add(obj.magazine.get(indice));                   
        }
         
        Vector<String> numeMagazine=new Vector<>();
        numeMagazine.add("MiniMarket"); //vector cu tipurile magazinelor in aceasta ordine
        numeMagazine.add("MediumMarket");
        numeMagazine.add("HyperMarket");
        
        boolean randLiber;
        
        try{
            FileWriter fw=new FileWriter("out.txt");
            PrintWriter pw=new PrintWriter(fw);
            for(i=0; i<numeMagazine.size(); i++){//voi printa magazinele in ordinea tipurilor 
                if(i>0)
                    pw.print("\n");
                pw.println(numeMagazine.get(i)); //voi printa tipul magazinului
                randLiber = false;
                for(j=0; j<magazineOrdine.size(); j++){
                    if(magazineOrdine.get(j).tip.equals(numeMagazine.get(i))){
                        if(randLiber)
                            pw.println("\n");
                        randLiber = true;
                        pw.println(magazineOrdine.get(j).nume); //printez numele magazinului
                        pw.println("");
                        Magazin aux=magazineOrdine.get(j);
                        //printez Totalurile magazinului
                        pw.println("Total "+aux.getTotalFaraTaxe()+" "+aux.getTotalCuTaxe()+" "+aux.getToTalCuTaxeScutite());
                        pw.println("");   
                        pw.println("Tara");
                        //printez tara urmat de totalurile magazinului in functie de aceasta
                        //le printez pe toate
                        for (Iterator it = keys.iterator(); it.hasNext(); ) {
                            String key = (String) it.next();
                            if(aux.getTotalTaraCuTaxe(key) == 0) //daca e unul, sunt toate totalurile=0
                                pw.println(key+" 0");
                            else
                                pw.println(key+" "+aux.getTotalTaraFaraTaxe(key)+" "+aux.getTotalTaraCuTaxe(key)+" "+aux.getTotalTaraCuTaxeScutite(key));
                        }
                            pw.println("");
                        Vector<Factura> facturiOrdine = new Vector<>();
                        //sortez facturile magazinului in ordinea crescatoare totalului cu taxe al fiecareia
                        for(k=0; k<magazineOrdine.get(j).v.size(); k++){
                            indice=0;
                            while(indice<facturiOrdine.size() && magazineOrdine.get(j).v.get(k).getTotalCuTaxe()> facturiOrdine.get(indice).getTotalCuTaxe())
                                indice++;
                            facturiOrdine.add(indice, magazineOrdine.get(j).v.get(k));
                        }
                        for(k=0; k<facturiOrdine.size(); k++){ //trec prin toate facturile ordonate ale magazinului
                            if(k>0) 
                                pw.print("\n");                          
                            pw.println(facturiOrdine.get(k).denumire); //Printez denumirea facturii
                            pw.println("");
                            Factura aux1=facturiOrdine.get(k);
                            //printez Totalurile facturii
                            pw.println("Total "+aux1.getTotalFaraTaxe()+" "+aux1.getTotalCuTaxe());
                            pw.println("");
                            pw.print("Tara");
                            //printez tara si totalurile fara taxe si cu taxe ale acestei tari pe linie, pt toate tarile
                            for (Iterator it = keys.iterator(); it.hasNext(); ) {
                                pw.print("\n");
                                String key = (String) it.next();
                                if(aux1.getTotalTaraFaraTaxe(key)==0)
                                    pw.print(key+" "+0);
                                else
                                    pw.print(key+" "+aux1.getTotalTaraFaraTaxe(key)+" "+aux1.getTotalTaraCuTaxe(key));
                            }
                            if(k<facturiOrdine.size()-1)
                                pw.print("\n");
                        }
                    }
                }
                if(i<2)
                    pw.print("\n");
            }
            pw.close();  
        }catch(IOException e){
           System.out.println("Nu s-a putut scrie");
        }
    
    }
    
    public static void main(String[] a) throws IOException{
        OutputClass oc=new OutputClass();
        File f=new File("taxe.txt");
        File f1=new File("produse.txt");
        File f2=new File("facturi.txt");
        oc.Scriere(f, f1, f2);
    }
       
} 