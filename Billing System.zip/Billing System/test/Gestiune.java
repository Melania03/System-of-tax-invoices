import java.io.*;
import java.util.*;

public class Gestiune {
    
    ArrayList<Produs> produse=new ArrayList<Produs>();
    ArrayList<Magazin> magazine=new ArrayList<Magazin>();
    TreeMap<String, TreeMap<String, Double>> taxe= new TreeMap<String, TreeMap<String, Double>>();
    static Gestiune obj=new Gestiune();
    
    //Singleton:
    private Gestiune(){       
    }

    public static Gestiune getInstance() {
        return obj;      
    }
    //Crearea vectorului de produse 
    public void citireProduse(File f) throws FileNotFoundException{
        int i=0,j=0;
        String m;
        ArrayList<String> tari=new ArrayList<String>();
        Scanner sc = new Scanner(f);
         
        m=sc.nextLine();
        String[] b=m.split(" "); //in tari voi avea cuvintele de pe prima linie
        for(String ss:b)
           tari.add(ss);
            
        tari.remove(0); //primele doua cuvinte Produs Categorie nu conteaza
        tari.remove(0); //raman doar tarile(RO, IT, SP)
        
        i=0;
        while(sc.hasNextLine()){
            sc.nextLine();
            i++; //numarul de produse(atatea linii cate produse. !Prima linie e deja citita pt tari)
        }
        
        int k=0;
        String prod, categ;
        sc.close();
        sc=new Scanner(f);
        sc.nextLine();      
        prod=sc.next(); //prima denumire de produs
        categ=sc.next(); //prima categorie
        for(j=0; j<tari.size()*i; i++){
            Produs p= new Produs(prod, categ, tari.get(k), sc.nextDouble()); //creez produsul
            produse.add(p); //si il adaug in vectorul de produse
                
            k++;
            if(k==tari.size()){
                k=0;  //daca s-au citit (ex: 3) preturi(un pret pt fiecare din cele 3 tari) se trece la urmatoarea linie
                if(sc.hasNext()){
                    sc.nextLine();
                    prod=sc.next(); //restul de produse si categorii
                    categ=sc.next();
                }
            }
                
            if(!sc.hasNextDouble()) //cand nu mai exista pret, se termina citirea
                break;
        }
                  
    }
    //Crearea dictionarului de taxe
    public void citireTaxe(File f) throws FileNotFoundException{
        String m;
        int i=0;
        ArrayList<String> tari=new ArrayList<>();
        ArrayList<String> categorii=new ArrayList<>();
        ArrayList<String> proc=new ArrayList<>();
        ArrayList<Double> procente = new ArrayList<>();
        TreeMap<String, Double> dictionar=new TreeMap<>(); //dictionar categorie, procent
        
        Scanner sc = new Scanner(f);
        
        m=sc.nextLine();
        String[] a=m.split(" ");
        for(String ss:a){
           tari.add(ss);
        }
        
        tari.remove(0);//primul cuvant Categorie/Tara nu conteaza
        
        while(sc.hasNext()){
            m=sc.next();
            categorii.add(m); //Vectorul cu denumirea categoriilor
            sc.nextLine();            
        }
        
        Scanner scc=new Scanner(f);
        scc.nextLine();
        int k=1,j=0;
        while(k <= tari.size()){
            for(i=0; i<k; i++)
                m=scc.next();
            m=scc.next();
            proc.add(m); //in proc voi pune pe rand, toate procentele unei tari 
            j++;
            if (scc.hasNextLine())
                scc.nextLine();
            if (j==categorii.size()) { //daca s-au citit procentele pt o coloana(tara) pe fiecare linie, se trece la urmatoarea tara(indicele k)
                scc.close();
                scc=new Scanner(f);
                scc.nextLine();
                k++;
                j=0;   
            }
        }
        
        for(i=0; i<proc.size(); i++)
            procente.add(Double.parseDouble( (String) proc.get(i)));
        
       for(i=0; i<tari.size(); i++){
            for(j=0; j<categorii.size(); j++)
                dictionar.put(categorii.get(j), procente.get((tari.size())*i+j)); //dictionar pt fiecare categorie-procent
            taxe.put(tari.get(i), dictionar);//pt fiecare tara pun in taxe dictionarul cu categorie-procent potrivit
            dictionar=new TreeMap<String, Double>(); //pt urmatoarea tara un dictionar categorie-procent nou
        }
          
    }
    
    public void citireMagazine(File f)  throws FileNotFoundException{       
        Scanner sc = new Scanner(f);
        int i ,j , k = 0;
        String m;
        ArrayList<String> numeMagazine = new ArrayList<>();
        ArrayList<String> numeFacturi = new ArrayList<>();
        Vector<ProdusComandat> prodcomand=new Vector<>();
        Vector<Factura> facturi=new Vector<>();
        while (sc.hasNext()){
            m=sc.next();    
            if(m.contains("Magazin")){
                k++; //numarul de Magazine
                String[] aux1=m.split(":");
                for(String ss:aux1)
                    numeMagazine.add(ss);
            }
        }
        for(i = 0; i < numeMagazine.size(); i++){
            if(numeMagazine.get(i).equals("Magazin"))
                numeMagazine.remove(i); //imi raman doar tipul magazinului si numele
        }
        
        sc.close();
        sc=new Scanner(f);
        while (sc.hasNext()){
            m=sc.next();    
            if(m.contains("Factura")){
                numeFacturi.add(m); //vector cu numele tuturor facturilor (Factura1, Factura2, Factura1, etc...)
            }
        }
        //produse si facturi
        int indice = 0, nrMagazin = 0;
        sc.close();
        sc=new Scanner(f);
        while (sc.hasNext()){
            m=sc.nextLine(); 
            if(m.contains("Factura")){ 
                sc.nextLine(); //sar de linia ce contine DenumireProdus Tara Cantitate
                String d = sc.nextLine();                    
                while(!d.equals("") && sc.hasNext()){
                    String aux[]=d.split(" ");
                    for(i=0; i<produse.size(); i++) //parcurg vectorul de produse
                        //daca gasesc un produs cu numele pe care eu il citesc si tara, iau acel produs si ii adaug taxa potrivita si cantitatea =>produscomandat
                        //aux[0]=denumirea produsului; aux[1]=tara; aux[2]=cantitatea
                        if((aux[0].equals(produse.get(i).getDenumire())) && (aux[1].equals(produse.get(i).getTaraOrigine()))){
                            ProdusComandat pc=new ProdusComandat(produse.get(i), taxe.get(aux[1]).get(produse.get(i).getCategorie()), Integer.parseInt(aux[2]));
                            prodcomand.add(pc); //il adaug la vectorul de produse comandate
                    }
                d=sc.nextLine();
                }
                //d este acum ultima linie si fac acelasi lucru pt aceasta
                if (!sc.hasNext()){
                    String aux[]=d.split(" ");
                    for(i=0; i<produse.size(); i++)
                        if((aux[0].equals(produse.get(i).getDenumire())) && (aux[1].equals(produse.get(i).getTaraOrigine()))){                          
                            ProdusComandat pc=new ProdusComandat(produse.get(i), taxe.get(aux[1]).get(produse.get(i).getCategorie()), Integer.parseInt(aux[2]));
                            prodcomand.add(pc);
                        }
                }
                           
                Factura fact = new Factura(numeFacturi.get(indice), prodcomand); //construiesc fact cu numele si vectorul de produse potrive, in ordinea citirii
                facturi.add(fact); //o adaug in vectorul de facturi
                prodcomand=new Vector<ProdusComandat>(); //reinitializez vectorul de produse comandate
                indice++;
            }

        }
        //magazine
        nrMagazin = 0;
        Vector<Factura> auxf = new Vector<Factura>();
        for(i = 0; i < numeFacturi.size(); i++){
            auxf.add(facturi.get(i)); //adaug facturi pt primul magazin
            if( i==numeFacturi.size()-1 || numeFacturi.get(i+1).equals("Factura1") ){ //daca se ajunge la ultima factura sau urmatoarea factura este Factura1
                MarketFactory mx=new MarketFactory(); //creez un magazin (cu Factory Pattern) cu argumentele: 
                //numele, care in numeMagazine este pe pozitie impara si TIPUL, care este pe pozitie para, si auxf, vectorul cu facturi de pana atunci 
                Magazin mc=mx.getInstance(numeMagazine.get(nrMagazin * 2 + 1), numeMagazine.get(nrMagazin * 2), auxf);
                nrMagazin++;
                auxf = new Vector<Factura>();
                magazine.add(mc); //adaug magazinul creat in vectorul de magazine
            }
           
        }
    }
    
}
