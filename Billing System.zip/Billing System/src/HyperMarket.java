import java.util.Vector;

public class HyperMarket extends Magazin {

    
    public HyperMarket(String nume, String tip, Vector<Factura> v) {
        super(nume, tip, v);

    }
    
    
    public double calculScutiriTaxe(){
        int i;
        for(i=0; i<this.v.size(); i++){
            if(v.get(i).getTotalCuTaxe() > 0.1*this.getTotalCuTaxe()) //Daca exista o factura cu totalul ei cu taxe > 10% din totalul tuturor facturilor
                return 0.01; //1%
        }
        return 0;
    }
    
    public String toString(){
        return tip+" "+nume+" "+v;
    }
    
}