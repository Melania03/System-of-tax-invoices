import java.util.Vector;

public class Factura {
    
    String denumire;
    Vector<ProdusComandat> vector=new Vector<>();
    public Factura(){
        
    }
    
    public Factura(String denumire, Vector<ProdusComandat> v){
        this.denumire = denumire;
        this.vector=v;
    }
    //Voi calcula totalul unei facturi in functie de cerinta(cu taxe, fara, total taxe, pt o tara)  
    double getTotalFaraTaxe(){
        int i;
        double s = 0;
        for(i = 0; i < vector.size(); i++) //in functie de numarul produselor comandate
            s = s + vector.get(i).getProdus().getPret() * vector.get(i).getCantitate(); //calculez totalul facturii fara taxe(pret produs*cantitate)   
       return Math.round(s*100.0)/100.0; //2 zecimale
      
    }
    //La fel si la celelalte
    double getTotalCuTaxe(){
        int i;
        double s = 0;
        for(i=0; i < vector.size(); i++)
            s = s + vector.get(i).getProdus().getPret() * vector.get(i).getCantitate()*(100+vector.get(i).getTaxa())/100;
        return Math.round(s*1000.0)/1000.0;
              
    }
    //Diferenta dintre totalul cu taxe - cel fara taxe
    double getTaxe(){ 
        int i;
        double s = 0;
        for(i=0; i < vector.size(); i++)
            s = s + vector.get(i).getProdus().getPret() * vector.get(i).getCantitate()*((100+vector.get(i).getTaxa())/100-1);
        return s;
    }
    
    double getTotalTaraFaraTaxe(String tara){
        int i;
        double s = 0;
        for(i = 0; i < vector.size(); i++)
            if (vector.get(i).getProdus().getTaraOrigine().equals(tara)) //pentru o anumita tara (primita ca parametru)
                s = s + vector.get(i).getProdus().getPret() * vector.get(i).getCantitate();
        return Math.round(s*100.0)/100.0;    
        
    }
    
    double getTotalTaraCuTaxe(String tara){
        int i;
        double s = 0;
        for(i = 0; i < vector.size(); i++)
            if (vector.get(i).getProdus().getTaraOrigine().equals(tara))
                s = s + vector.get(i).getProdus().getPret() * vector.get(i).getCantitate()*(100+vector.get(i).getTaxa())/100;
        return Math.round(s*1000.0)/1000.0;
        
    }
    
    double getTaxeTara(String tara){
      int i;
        double s = 0;
        for(i = 0; i < vector.size(); i++)
            if (vector.get(i).getProdus().getTaraOrigine().equals(tara))
                s = s + vector.get(i).getProdus().getPret() * vector.get(i).getCantitate()*((100+vector.get(i).getTaxa())/100-1);
        return s;
    }
    public String toString(){
        return denumire+" "+vector;
    }

}
    