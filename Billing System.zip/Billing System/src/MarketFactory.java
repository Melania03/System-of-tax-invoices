import java.util.TreeMap;
import java.util.Vector;

public class MarketFactory {
    //in functie de numele pe care il primesc parametru, o sa fac un obiect potrivit
    public Magazin getInstance(String s, String str,  Vector<Factura> v){
        if(str.contains("Mini") || str.contains("mini"))
            return new MiniMarket(s, str, v);
        else if(str.contains("Medium") || str.contains("medium"))
            return new MediumMarket(s, str, v);
        else if (str.contains("Hyper") || str.contains("hyper"))
            return new HyperMarket(s, str, v);
        return null;
    }
}
