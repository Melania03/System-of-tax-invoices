public class Produs {
    private String denumire;
    private String categorie;
    private String taraOrigine;
    private double pret;
    //Clasa Produs conform cerintei, + constructorul care seteaza toate datele
    public Produs(String d, String c, String t, double p){
        this.denumire=d;
        this.categorie=c;
        this.pret=p;
        this.taraOrigine=t;
    }

    
    void setDenumire(String denumire){
        this.denumire = denumire;
        
    }
    
    String getDenumire(){
        return denumire;
        
    }
    
    void setCategorie(String categorie){
        this.categorie = categorie;
        
    }
    
    String getCategorie(){
        return categorie;
        
    }
    
    void setTaraOrigine(String tara){
        this.taraOrigine = tara;
        
    }
    
    String getTaraOrigine(){
        return taraOrigine;
        
    }
    
    void setPret(double pret){
        this.pret = pret;
        
    }
    
    double getPret(){
        return pret;
        
    }
    
    public String toString(){
       return "Produsul: "+denumire+" "+categorie+" "+taraOrigine+" "+pret;
   }
}
