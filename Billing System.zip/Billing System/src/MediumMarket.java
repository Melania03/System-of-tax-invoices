import java.io.*;
import java.util.*;

public class MediumMarket extends Magazin {
   
    public MediumMarket(String nume, String tip, Vector<Factura> v) {
        super(nume, tip, v);
    }
  
    public double calculScutiriTaxe() {
        int i=0, j, k;
        double s=0;
        boolean b = false;
        String m;
        ArrayList<String> produse=new ArrayList<String>();
        try{
        File file = new File("produse.txt");
        Scanner sc = new Scanner(file);
        sc.nextLine();
        //pun in produse doar categoria 
        while(sc.hasNext()){
            m=sc.next();
            i++;
            if(i==2){ //al doilea cuvant de pe fiecare linie este categoria
               produse.add(m);
               i=0;
               sc.nextLine();
            }
        }   
        //pentru fiecare categorie de produs, voi calcula suma produselor comandate din toate facturile
        for(k=0; k<produse.size(); k++){
            s=0;
            for(i=0; i<v.size(); i++)
                for(j=0; j<v.get(i).vector.size(); j++)
                    if(v.get(i).vector.get(j).getProdus().getCategorie().equals(produse.get(k))){
                        ProdusComandat a = v.get(i).vector.get(j);
                        s = s + a.getProdus().getPret() * a.getCantitate()*(100+a.getTaxa())/100;
                    }
            if (s>0.5*this.getTotalCuTaxe()) 
                return 0.05;    //5%
        }
        }catch(IOException e){
            System.out.println("Nu s-a citit");
        }
        return 0;   //0 daca nu exista produse comandate insumate ca pret ce depasesc 50% total Magazin 
                           
    }
    
    public String toString(){
        return tip+" "+nume+" "+v;
    }

}