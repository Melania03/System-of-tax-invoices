import java.awt.Desktop;
import java.io.*;
import java.util.logging.*;
import javax.swing.*;

public class IncarcareFisiere extends JFrame {
    private javax.swing.JButton jButton1;
    private javax.swing.JButton jButton2;
    private javax.swing.JButton jButton3;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JPanel jPanel2;
    private javax.swing.JButton jButton4;
    public File file1, file2, file3;
    
    public IncarcareFisiere(String str){
        
        super(str);
        
        jPanel1 = new javax.swing.JPanel();
        jPanel2 = new javax.swing.JPanel();
        jButton1 = new javax.swing.JButton();
        jButton2 = new javax.swing.JButton();
        jButton3 = new javax.swing.JButton();
        jButton4 = new javax.swing.JButton();
       
        final JFileChooser fc = new JFileChooser();

        setDefaultCloseOperation(javax.swing.WindowConstants.DISPOSE_ON_CLOSE);

        jPanel1.setBackground(new java.awt.Color(255, 204, 204));

        jPanel2.setBackground(new java.awt.Color(153, 153, 255));


        jButton1.setBackground(new java.awt.Color(255, 0, 51));
        jButton1.setFont(new java.awt.Font("Comic Sans MS", 1, 16)); 
        jButton1.setText("Incarcare taxe");
        //primul buton ma va lasa sa imi selectez fisierul de taxe
        jButton1.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                int k=0;
                if (evt.getSource() == jButton1) {
                    int returnVal = fc.showOpenDialog(null);

                    if (returnVal == JFileChooser.APPROVE_OPTION) {
                        file1 = fc.getSelectedFile();
                    }
                    //daca nu va fi selectat fisierul corect, va da eroare si ma va lasa sa aleg din nou
                    while(!fc.getSelectedFile().getName().contains("taxe")){
                        k++;
                        JOptionPane.showMessageDialog(null, "Eroare, nu ai incarcat fisierul bun!", "Eroare TAXE", JOptionPane.ERROR_MESSAGE); 
                        int returnV = fc.showOpenDialog(null);
                        if (returnV == JFileChooser.APPROVE_OPTION) {
                                file1 = fc.getSelectedFile();
                            }
                        if (k==2)
                            break;
                    }
                }
            }
        });

        //La fel si pentru butoanele 2 si 3 care vor incarca produse.txt, respectiv facturi.txt
        
        jButton2.setBackground(new java.awt.Color(255, 0, 51));
        jButton2.setFont(new java.awt.Font("Comic Sans MS", 1, 16)); 
        jButton2.setText("Incarcare produse");
        jButton2.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                int k=0;
                if (evt.getSource() == jButton2) {
                    int returnVal = fc.showOpenDialog(null);

                    if (returnVal == JFileChooser.APPROVE_OPTION) {
                        file2 = fc.getSelectedFile();
                    }
                    while(!fc.getSelectedFile().getName().contains("produse")){
                        k++;
                        JOptionPane.showMessageDialog(null, "Eroare, nu ai incarcat fisierul bun!", "Eroare PRODUSE", JOptionPane.ERROR_MESSAGE); 
                        int returnV = fc.showOpenDialog(null);
                        if (returnV == JFileChooser.APPROVE_OPTION) {
                            file2 = fc.getSelectedFile();
                        } 
                        if(k==2)
                            break;
                    }
                }
            }
        });

        jButton3.setBackground(new java.awt.Color(255, 0, 51));
        jButton3.setFont(new java.awt.Font("Comic Sans MS", 1, 16)); 
        jButton3.setText("Incarcare facturi");
        jButton3.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                int k=0;
                if (evt.getSource() == jButton3) {
                    int returnVal = fc.showOpenDialog(null);

                    if (returnVal == JFileChooser.APPROVE_OPTION) {
                        file3 = fc.getSelectedFile();
                    }
                    while(!fc.getSelectedFile().getName().contains("facturi")){
                        k++;
                        JOptionPane.showMessageDialog(null, "Eroare, nu ai incarcat fisierul bun!", "Eroare FACTURI", JOptionPane.ERROR_MESSAGE); 
                        int returnV = fc.showOpenDialog(null);
                        if (returnV == JFileChooser.APPROVE_OPTION) {
                            file3 = fc.getSelectedFile();
                        }
                        if(k==2)
                            break;
                        
                    }
                }
            }
        });

        jButton4.setBackground(new java.awt.Color(255, 0, 51));
        jButton4.setFont(new java.awt.Font("Comic Sans MS", 1, 16)); 
        jButton4.setText("Gestiune");
          jButton4.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                 if (evt.getSource() == jButton4) {
                    OutputClass instance=new OutputClass(); //in clasa OutputClass aveam generarea unui obiect gestiune si printarea in out.txt
                     try {
                          instance.Scriere(file1, file2, file3); //apelez functia de printare
                          Desktop.getDesktop().open(new java.io.File("out.txt")); //afisez out.txt (vedeti README)
                     } catch (IOException e) {
                         e.printStackTrace();
                     }
        }}});

        javax.swing.GroupLayout jPanel2Layout = new javax.swing.GroupLayout(jPanel2);
        jPanel2.setLayout(jPanel2Layout);
        jPanel2Layout.setHorizontalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addGap(339, 339, 339)
                .addGroup(jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addComponent(jButton4, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton3, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(jButton2, javax.swing.GroupLayout.DEFAULT_SIZE, 205, Short.MAX_VALUE)
                    .addComponent(jButton1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addContainerGap(377, Short.MAX_VALUE))
        );
        jPanel2Layout.setVerticalGroup(
            jPanel2Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel2Layout.createSequentialGroup()
                .addContainerGap(38, Short.MAX_VALUE)
                .addComponent(jButton1, javax.swing.GroupLayout.PREFERRED_SIZE, 66, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jButton2, javax.swing.GroupLayout.PREFERRED_SIZE, 69, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(30, 30, 30)
                .addComponent(jButton3, javax.swing.GroupLayout.PREFERRED_SIZE, 78, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(32, 32, 32)
                .addComponent(jButton4, javax.swing.GroupLayout.PREFERRED_SIZE, 65, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(22, 22, 22))
        );

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(70, 70, 70)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addContainerGap(76, Short.MAX_VALUE))
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, jPanel1Layout.createSequentialGroup()
                .addContainerGap(63, Short.MAX_VALUE)
                .addComponent(jPanel2, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(61, 61, 61))
        );

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
        );
    
        pack();
        setLocationRelativeTo(null);
        setVisible(true);
        show();
    }
     
}

