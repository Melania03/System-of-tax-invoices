public class ProdusComandat {
    private Produs produs;
    private double taxa;
    private int cantitate;
    //ProdusComandat conform cerintei, + consructorul care seteaza datele
    public ProdusComandat(Produs p, double t, int c){
        this.produs=p;
        this.taxa=t;
        this.cantitate=c;
    }
    
    void setProdus(Produs produs){
        this.produs=produs;
        
    }
    
    Produs getProdus(){
        return produs;
        
    }
    
    void setTaxa(double taxa){
        this.taxa = taxa;
        
    }
    
    double getTaxa(){
        return taxa;
        
    }
    
    void setCantitate(int cantitate){
        this.cantitate = cantitate;
        
    }
    
    int getCantitate(){
        return cantitate;
        
    }
    
    public String toString(){
       return "ProdusComandat: "+produs+" "+cantitate+" "+taxa;
   }

}
