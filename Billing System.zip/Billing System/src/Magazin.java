import java.util.Vector;

public abstract class Magazin implements IMagazin {
    
    String nume, tip;
    Vector<Factura> v=new Vector<>();
    
    public Magazin(){
        
    }
    public Magazin(String nume, String tip, Vector<Factura> v){
        this.nume=nume;
        this.tip=tip;
        this.v=v;
    }
    
  // e ca la clasa Factura, doar ca in loc de vectorul de produse comandate, este cel de facturi
  public double getTotalFaraTaxe(){
        int i;
        double s = 0;
        for(i = 0; i < v.size(); i++)
            s = s + v.get(i).getTotalFaraTaxe(); // + totalul fara taxe al unei facturi
        return Math.round(s*100.0)/100.0;
              
    }
    
    public double getTotalCuTaxe(){   
        int i;
        double s = 0;
        for(i = 0; i < v.size(); i++)
            s = s + v.get(i).getTotalCuTaxe();
        return Math.round(s*1000.0)/1000.0;
    }
    
    public double getToTalCuTaxeScutite(){
        int i;
        double s = 0;
        for(i = 0; i < v.size(); i++)
            s = s + v.get(i).getTotalCuTaxe();
         return Math.round(s * (1-calculScutiriTaxe())*10000.0)/10000.0;
    }
    
    public double getTotalTaraFaraTaxe(String tara){
        int i;
        double s = 0;
        for(i = 0; i < v.size(); i++)
            s = s + v.get(i).getTotalTaraFaraTaxe(tara);
        return Math.round(s*100.0)/100.0;
        
    }
    
    public double getTotalTaraCuTaxe(String tara){
        int i;
        double s = 0;
        for(i = 0; i < v.size(); i++)
            s = s + v.get(i).getTotalTaraCuTaxe(tara);
        return Math.round(s*1000.0)/1000.0;
        
    }
    
    public double getTotalTaraCuTaxeScutite(String tara){
        int i;
        double s = 0;
        for(i = 0; i < v.size(); i++)
            s = s + v.get(i).getTotalTaraCuTaxe(tara);
        return Math.round(s * (1-calculScutiriTaxe())*10000.0)/10000.0;
    }
    
     public String toString(){
        return tip+" "+nume+" "+v;
    }
          
}