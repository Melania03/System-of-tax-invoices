import java.io.*;
import java.util.*;


public class MiniMarket extends Magazin {
    
    
    public MiniMarket(String nume, String tip, Vector<Factura> v) {
        super(nume, tip, v);

    }   
    
    public double calculScutiriTaxe() {
        int i, j;
        String m;
        try{
        File file = new File("produse.txt");
        Scanner sc = new Scanner(file);
        m = sc.nextLine();
        String[] t = m.split(" "); //retin prima linie unde am si tarile in t

        for(i=2; i<t.length; i++){ //primele doua cuvinte nu conteaza, deci NR TARI= t.length-2;
            double suma=0;
            for(j=0; j<v.size(); j++)
                suma=suma+v.get(j).getTotalTaraCuTaxe(t[i]); //t[i] = tara. fac suma produselor comandate dintr-o factura pentru fiecare tara 
            if(suma>0.5*this.getTotalCuTaxe())
                return 0.1; //10%
        }
        }catch(IOException e){
           System.out.println("Nu s-a putut citi");
        }
        return 0;
    }
    
    
    public String toString(){
        return tip+" "+nume+" "+v;
    }
    
}